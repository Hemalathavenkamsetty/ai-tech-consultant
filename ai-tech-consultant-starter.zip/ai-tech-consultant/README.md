# AI Tech Consultant Capstone

Starter implementation for the three connected tasks in the capstone brief:
- **Task 1 — Knowledge Brain (Python/FastAPI):** polite sitemap ingestion, article storage, basic keyword retrieval, Claude-grounded answers, citations, expert feedback API.
- **Task 2 — Inbox Agent (TypeScript/Express):** email validation, calls Task 1's API, creates a conservative reply draft, requires human review.
- **Task 3 — Meeting to Scope (Python/FastAPI):** calls Task 1, asks Claude for a structured scope/estimate/proposal, requires human approval.

## Requirements
- Docker + Docker Compose, or Python 3.12 and Node.js 22.
- An Anthropic API key for generated Claude answers and scope creation.

## Run locally with Docker
1. Copy `task1-knowledge-brain/.env.example` to `task1-knowledge-brain/.env`.
2. Add your `ANTHROPIC_API_KEY` to that file if available.
3. Run `docker compose up --build`.
4. Open:
   - Knowledge Brain docs: http://localhost:8000/docs
   - Inbox Agent health: http://localhost:3002/health
   - Meeting Scope docs: http://localhost:8003/docs
5. Trigger ingestion with `POST http://localhost:8000/ingest` and JSON body `{"max_pages":100}`.

## API examples

Ask the Knowledge Brain:
```bash
curl -X POST http://localhost:8000/ask \
  -H "Content-Type: application/json" \
  -d '{"question":"How do I configure a feature?","top_k":5}'
```

Draft an email:
```bash
curl -X POST http://localhost:3002/draft \
  -H "Content-Type: application/json" \
  -d '{"from":"customer@example.com","subject":"Help with my site","body":"How can I change the layout?"}'
```

Create a scope:
```bash
curl -X POST http://localhost:8003/scope \
  -H "Content-Type: application/json" \
  -d '{"client_name":"Example Client","transcript":"The client wants a new search filter. They need it to filter products by category and price. The delivery date and budget are not yet agreed."}'
```

## Important limitations to address before production
- The current retriever is a transparent keyword baseline, not a vector database/embedding implementation.
- Image URLs and alt text are stored, but vision-based screenshot interpretation is not implemented yet.
- Daily scheduled sitemap synchronization, durable job checkpoints, and robust deletion detection need production hardening.
- Task 2 uses a safe draft scaffold; Claude reply generation, feedback storage, 20-in-a-row automation gates, and quality rollback remain to be implemented.
- Task 3 has a structured Claude output path and prior-scope input, but a full semantic change diff and persistent approval workflow remain to be implemented.
- Add authentication/rate limiting before exposing APIs publicly.
- Model IDs and API availability can change; configure a model currently available to your Anthropic account.
- Do not claim evaluation scores until tests have actually been run. Create at least 20 evaluation cases per task and record quality, latency, and cost in `EVALS.md`.

## Environment variables
See each task's `.env.example`. Never commit API keys or real customer data.
