import express from "express";
import { z } from "zod";

const app = express();
app.use(express.json({ limit: "1mb" }));

const env = {
  port: Number(process.env.PORT ?? 3002),
  knowledgeApiUrl: process.env.KNOWLEDGE_API_URL ?? "http://localhost:8000",
};
const EmailSchema = z.object({
  from: z.string().email(),
  subject: z.string().min(1).max(300),
  body: z.string().min(1).max(20000),
});
type KnowledgeAnswer = { answer: string; found_evidence: boolean; sources: { title: string; url: string; snippet: string }[] };

app.get("/health", (_req, res) => res.json({ status: "ok", service: "inbox-agent" }));

app.post("/draft", async (req, res) => {
  const parsed = EmailSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const email = parsed.data;
  try {
    const knowledgeResponse = await fetch(`${env.knowledgeApiUrl}/ask`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ question: `${email.subject}\n${email.body}`, top_k: 5 }),
    });
    if (!knowledgeResponse.ok) return res.status(502).json({ error: "Knowledge Brain API failed" });
    const knowledge = await knowledgeResponse.json() as KnowledgeAnswer;
    // Safe baseline: provide a grounded draft scaffold; connect Claude and feedback policy before production.
    const draft = knowledge.found_evidence
      ? `Hello,\n\nThank you for contacting us about "${email.subject}".\n\n${knowledge.answer}\n\nPlease let us know if you need any further help.\n\nBest regards,\nSupport Team`
      : `Hello,\n\nThank you for contacting us. We need a support specialist to verify the answer to your question before we can give you accurate guidance. We will follow up after review.\n\nBest regards,\nSupport Team`;
    res.json({ category: "support_question", draft, requiresHumanReview: true, sources: knowledge.sources, knowledgeFoundEvidence: knowledge.found_evidence });
  } catch {
    res.status(502).json({ error: "Could not reach Knowledge Brain API" });
  }
});

app.listen(env.port, () => console.log(`Inbox Agent listening on port ${env.port}`));
