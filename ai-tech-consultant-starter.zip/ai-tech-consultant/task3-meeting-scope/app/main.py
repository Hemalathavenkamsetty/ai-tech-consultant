import os, json
from fastapi import FastAPI, HTTPException
from pydantic import ValidationError
from anthropic import Anthropic
from .schemas import TranscriptRequest, ScopeResponse

app = FastAPI(title="Meeting to Scope of Work", version="0.1.0")
KNOWLEDGE_API_URL = os.getenv("KNOWLEDGE_API_URL", "http://localhost:8000")
CLAUDE_MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-5")

@app.get("/health")
def health():
    return {"status": "ok", "service": "meeting-scope"}

@app.post("/scope")
async def create_scope(body: TranscriptRequest):
    # Check existing product functionality before assuming custom development is needed.
    import httpx
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            kresp = await client.post(f"{KNOWLEDGE_API_URL}/ask", json={
                "question": "Existing product features and settings relevant to these client needs:\n" + body.transcript[:12000],
                "top_k": 8
            })
            knowledge = kresp.json() if kresp.status_code == 200 else {"answer": "Knowledge Brain unavailable; verify existing features manually.", "sources": []}
    except Exception:
        knowledge = {"answer": "Knowledge Brain unavailable; verify existing features manually.", "sources": []}

    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        raise HTTPException(503, "Set ANTHROPIC_API_KEY to generate a structured scope.")
    client = Anthropic(api_key=api_key)
    prompt = f"""
Convert this transcript into a cautious software project scope.
Return ONLY valid JSON with keys: client_name, requirements, questions_for_client, risks, exclusions, total_estimated_hours, proposal_draft, requires_human_approval.
Each requirements item: title, description, hours (number), confidence (low/medium/high), assumptions (array of strings).
Separate confirmed requests from assumptions. Ask questions for ambiguity. Include contingency risks. Never promise features not agreed.
Prefer a documented existing setting over custom development when the knowledge sources support it.
Set requires_human_approval to true. This is a draft, not a contract.
Client: {body.client_name}
Previous scope JSON (if any): {json.dumps(body.previous_scope, ensure_ascii=False)[:10000]}
Transcript: {body.transcript[:50000]}
Knowledge Brain answer and sources: {json.dumps(knowledge, ensure_ascii=False)[:12000]}
"""
    try:
        msg = client.messages.create(model=CLAUDE_MODEL, max_tokens=3000,
            system="You are a senior technical consultant. Be precise, conservative, and honest about uncertainty.",
            messages=[{"role": "user", "content": prompt}])
        raw = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
        start, end = raw.find("{"), raw.rfind("}")
        if start < 0 or end <= start:
            raise ValueError("Model did not return JSON")
        result = ScopeResponse.model_validate_json(raw[start:end])
        result.requires_human_approval = True
        return {"scope": result.model_dump(), "knowledge_sources": knowledge.get("sources", [])}
    except (ValueError, ValidationError) as exc:
        raise HTTPException(502, f"Could not validate generated scope: {str(exc)[:300]}")
