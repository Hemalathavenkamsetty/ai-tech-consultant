from pydantic import BaseModel, Field
from typing import Literal

class TranscriptRequest(BaseModel):
    client_name: str = Field(min_length=1, max_length=200)
    transcript: str = Field(min_length=50, max_length=100000)
    previous_scope: dict | None = None

class ScopeItem(BaseModel):
    title: str
    description: str
    hours: float = Field(ge=0)
    confidence: Literal["low", "medium", "high"] = "medium"
    assumptions: list[str] = []

class ScopeResponse(BaseModel):
    client_name: str
    requirements: list[ScopeItem]
    questions_for_client: list[str]
    risks: list[str]
    exclusions: list[str]
    total_estimated_hours: float
    proposal_draft: str
    requires_human_approval: bool = True
