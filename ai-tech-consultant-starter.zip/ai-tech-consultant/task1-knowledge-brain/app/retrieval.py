import re
from collections import Counter
from sqlalchemy import select
from .db import SessionLocal, Article

STOPWORDS = set("the a an and or but is are was were to of in on for from with how what where when can do does i my your it this that".split())

def tokens(text: str) -> list[str]:
    return [t for t in re.findall(r"[a-zA-Z0-9_'-]+", text.lower()) if len(t) > 1 and t not in STOPWORDS]

def retrieve(question: str, top_k: int = 5) -> list[dict]:
    q = Counter(tokens(question))
    if not q:
        return []
    with SessionLocal() as db:
        articles = db.scalars(select(Article).where(Article.active == True)).all()
    scored = []
    for article in articles:
        words = tokens(article.title + " " + article.content)
        counts = Counter(words)
        overlap = sum(min(q[t], counts[t]) for t in q)
        if overlap:
            # Lightweight baseline ranking; replace with embeddings for production.
            title_bonus = sum(2 for t in q if t in tokens(article.title))
            score = (overlap + title_bonus) / ((len(counts) + 10) ** 0.25)
            scored.append((score, article, overlap))
    scored.sort(key=lambda x: x[0], reverse=True)
    result = []
    for score, article, overlap in scored[:top_k]:
        result.append({"title": article.title or article.url, "url": article.url,
                       "content": article.content, "score": round(score, 3)})
    return result
