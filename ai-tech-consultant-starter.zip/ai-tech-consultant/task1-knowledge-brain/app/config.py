from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    anthropic_api_key: str = ""
    claude_model: str = "claude-sonnet-4-5"
    database_url: str = "sqlite:///./knowledge.db"
    chroma_path: str = "./chroma_data"
    sitemap_url: str = "https://support.brilliantdirectories.com/support/sitemap.xml"
    crawl_delay_seconds: float = 1.0
    max_pages_per_run: int = 1000
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
