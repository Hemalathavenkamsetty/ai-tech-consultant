from pydantic import BaseModel, Field, HttpUrl
from typing import Optional

class AskRequest(BaseModel):
    question: str = Field(min_length=3, max_length=4000)
    top_k: int = Field(default=5, ge=1, le=12)

class Source(BaseModel):
    title: str
    url: str
    snippet: str

class AskResponse(BaseModel):
    answer: str
    found_evidence: bool
    sources: list[Source]

class IngestRequest(BaseModel):
    sitemap_url: Optional[HttpUrl] = None
    max_pages: int = Field(default=1000, ge=1, le=10000)

class FeedbackRequest(BaseModel):
    question: str = Field(min_length=3)
    answer: str = Field(min_length=1)
    expert_answer: str = Field(min_length=1)
    source_urls: list[str] = []
