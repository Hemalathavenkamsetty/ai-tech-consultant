import asyncio, hashlib, re, time
from urllib.parse import urlparse
import httpx
from bs4 import BeautifulSoup
from sqlalchemy import select
from .config import settings
from .db import SessionLocal, Article

USER_AGENT = "AI-Tech-Consultant-StudentProject/1.0 (polite sitemap ingestion)"

def clean_text(html: str) -> tuple[str, str]:
    soup = BeautifulSoup(html, "html.parser")
    for node in soup(["script", "style", "noscript", "svg", "nav", "footer"]):
        node.decompose()
    title = soup.title.get_text(" ", strip=True) if soup.title else ""
    # Keep image alt text and captions: screenshots are stored as references for later multimodal processing.
    image_notes = []
    for img in soup.find_all("img"):
        alt = (img.get("alt") or "").strip()
        src = (img.get("src") or "").strip()
        if alt or src:
            image_notes.append(f"[Image: alt={alt}; src={src}]")
    text = re.sub(r"\s+", " ", soup.get_text(" ", strip=True))
    if image_notes:
        text += "\n\n" + "\n".join(image_notes)
    return title, text[:100000]

async def get_sitemap_urls(client: httpx.AsyncClient, sitemap_url: str, limit: int) -> list[str]:
    response = await client.get(sitemap_url)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "xml")
    locs = [loc.get_text(strip=True) for loc in soup.find_all("loc")]
    # Handle sitemap indexes politely and only one level deep.
    nested = [u for u in locs if u.endswith(".xml") or "sitemap" in u.lower()]
    page_urls = [u for u in locs if u not in nested]
    for sitemap in nested:
        if len(page_urls) >= limit:
            break
        try:
            await asyncio.sleep(settings.crawl_delay_seconds)
            child = await client.get(sitemap)
            child.raise_for_status()
            child_soup = BeautifulSoup(child.text, "xml")
            page_urls.extend(loc.get_text(strip=True) for loc in child_soup.find_all("loc"))
        except httpx.HTTPError:
            continue
    # De-duplicate while preserving order; only HTTP(S) URLs.
    return list(dict.fromkeys(u for u in page_urls if urlparse(u).scheme in {"http", "https"}))[:limit]

async def ingest(sitemap_url: str | None = None, max_pages: int | None = None) -> dict:
    sitemap_url = sitemap_url or settings.sitemap_url
    max_pages = max_pages or settings.max_pages_per_run
    headers = {"User-Agent": USER_AGENT}
    timeout = httpx.Timeout(30.0)
    async with httpx.AsyncClient(headers=headers, timeout=timeout, follow_redirects=True) as client:
        urls = await get_sitemap_urls(client, sitemap_url, max_pages)
        seen = set()
        changed = 0
        errors = []
        with SessionLocal() as db:
            for index, url in enumerate(urls, start=1):
                try:
                    if urlparse(url).netloc != urlparse(sitemap_url).netloc:
                        # Avoid crawling unrelated hosts listed by a sitemap.
                        continue
                    await asyncio.sleep(settings.crawl_delay_seconds)
                    resp = await client.get(url)
                    resp.raise_for_status()
                    title, content = clean_text(resp.text)
                    if len(content.strip()) < 30:
                        continue
                    digest = hashlib.sha256((title + "\n" + content).encode()).hexdigest()
                    seen.add(url)
                    old = db.get(Article, url)
                    if old and old.content_hash == digest and old.active:
                        continue
                    if old:
                        old.title, old.content, old.content_hash, old.active = title, content, digest, True
                    else:
                        db.add(Article(url=url, title=title, content=content, content_hash=digest, active=True))
                    changed += 1
                    if index % 20 == 0:
                        db.commit()
                except Exception as exc:
                    errors.append({"url": url, "error": str(exc)[:300]})
            db.commit()
            # Only deactivate missing pages if the sitemap completed successfully.
            # If it was partial or failed, preserve old articles rather than deleting valid knowledge.
            if urls and not errors:
                current = set(urls)
                for article in db.scalars(select(Article).where(Article.active == True)).all():
                    if article.url not in current:
                        article.active = False
                db.commit()
        return {"discovered": len(urls), "changed": changed, "errors": errors[:30],
                "note": "Images are currently indexed as alt text and URLs; visual screenshot understanding requires a vision-capable model integration."}
