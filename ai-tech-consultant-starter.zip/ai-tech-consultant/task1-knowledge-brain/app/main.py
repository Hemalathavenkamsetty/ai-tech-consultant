from fastapi import FastAPI, HTTPException
from sqlalchemy import select
from .config import settings
from .db import init_db, SessionLocal, Article, ExpertFeedback
from .schemas import AskRequest, IngestRequest, FeedbackRequest
from .ingestion import ingest
from .answering import answer_question
import json

app = FastAPI(title="AI Tech Consultant — Knowledge Brain", version="0.1.0",
              description="Grounded support answers with article citations. Task 2 and Task 3 call this API.")
@app.on_event("startup")
def startup():
    init_db()

@app.get("/health")
def health():
    return {"status": "ok", "service": "knowledge-brain"}

@app.get("/articles")
def list_articles(limit: int = 50, offset: int = 0):
    if limit < 1 or limit > 200 or offset < 0:
        raise HTTPException(400, "limit must be 1-200 and offset must be >= 0")
    with SessionLocal() as db:
        rows = db.scalars(select(Article).where(Article.active == True).order_by(Article.title).offset(offset).limit(limit)).all()
        return {"items": [{"title": a.title, "url": a.url, "indexed_at": str(a.indexed_at)} for a in rows],
                "limit": limit, "offset": offset}

@app.post("/ingest")
async def ingest_endpoint(body: IngestRequest):
    try:
        return await ingest(str(body.sitemap_url) if body.sitemap_url else None, body.max_pages)
    except Exception as exc:
        raise HTTPException(502, f"Ingestion failed: {str(exc)[:300]}")

@app.post("/ask")
def ask(body: AskRequest):
    try:
        return answer_question(body.question, body.top_k)
    except Exception as exc:
        raise HTTPException(502, f"Answer generation failed: {str(exc)[:300]}")

@app.post("/feedback")
def feedback(body: FeedbackRequest):
    with SessionLocal() as db:
        row = ExpertFeedback(question=body.question, original_answer=body.answer,
                             expert_answer=body.expert_answer, source_urls=json.dumps(body.source_urls))
        db.add(row)
        db.commit()
        db.refresh(row)
        return {"saved": True, "feedback_id": row.id}

@app.get("/stats")
def stats():
    with SessionLocal() as db:
        total = len(db.scalars(select(Article).where(Article.active == True)).all())
        feedback_count = len(db.scalars(select(ExpertFeedback)).all())
    return {"active_articles": total, "expert_feedback_count": feedback_count}
