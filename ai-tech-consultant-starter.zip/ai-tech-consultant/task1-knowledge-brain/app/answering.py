from anthropic import Anthropic
from .config import settings
from .retrieval import retrieve

def answer_question(question: str, top_k: int = 5) -> dict:
    hits = retrieve(question, top_k)
    if not hits:
        return {"answer": "I couldn't find supporting information in the indexed help center. Please ask a human expert to review this question.",
                "found_evidence": False, "sources": []}
    context = "\n\n".join(
        f"SOURCE {i+1}\nTitle: {h['title']}\nURL: {h['url']}\nContent: {h['content'][:7000]}"
        for i, h in enumerate(hits)
    )
    if not settings.anthropic_api_key:
        # Useful for local development without an API key, but does not fabricate an answer.
        return {"answer": "Relevant articles were found, but ANTHROPIC_API_KEY is not configured, so an AI answer was not generated. Review the cited sources below.",
                "found_evidence": True,
                "sources": [{"title": h["title"], "url": h["url"], "snippet": h["content"][:400]} for h in hits]}
    client = Anthropic(api_key=settings.anthropic_api_key)
    response = client.messages.create(
        model=settings.claude_model,
        max_tokens=900,
        system=("You are a careful software-product support consultant. Answer only from the supplied sources. "
                "Cite claims inline as [1], [2] matching the source order. If the sources do not answer the question, "
                "say that clearly and recommend human review. Never invent product settings, policies, or URLs."),
        messages=[{"role": "user", "content": f"QUESTION:\n{question}\n\nSOURCES:\n{context}"}],
    )
    answer = "".join(block.text for block in response.content if getattr(block, "type", "") == "text")
    return {"answer": answer, "found_evidence": True,
            "sources": [{"title": h["title"], "url": h["url"], "snippet": h["content"][:400]} for h in hits]}
