from app.retrieval import tokens

def test_tokens_removes_common_stopwords():
    assert "refund" in tokens("How do I request a refund?")
    assert "the" not in tokens("the refund")
